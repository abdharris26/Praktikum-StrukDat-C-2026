#soal 1

stok = [15, 50, 30, 25,50]
stok.append(100)

stok.insert(2,75)

stok.sort(reverse = True)






print(stok)









print(stok)


