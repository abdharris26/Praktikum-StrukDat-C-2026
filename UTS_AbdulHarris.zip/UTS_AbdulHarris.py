print("*soal nomor 1*")

pengunjung_hari_ini = [ 
{"id": "M001", "nama": "Rina",   "usia": 20, "kategori": "Fiksi", "kembali": False}, 
{"id": "M002", "nama": "Hendra", "usia": 23, "kategori": "Sains", "kembali": True}, 
{"id": "M003", "nama": "Siti",   "usia": 19, "kategori": "Fiksi", "kembali": False}, 
{"id": "M004", "nama": "Taufik", "usia": 21, "kategori": "Hukum", "kembali": True}, 
{"id": "M005", "nama": "Yuni",   "usia": 18, "kategori": "Sains", "kembali": False}, 
{"id": "M006", "nama": "Bagas",  "usia": 22, "kategori": "Hukum", "kembali": False}, 
] 
 
def tampilkan_pengunjung():
    print("\n==== DATA PENGUNJUNG PERPUSTAKAAN =====")
    print("NO | ID  | Nama | Usia | Kategori | Status Kembali")
    print("---+-----+------+------+---------+-------------")
    
    no = 1
    for p in pengunjung_hari_ini:
        status = "Sudah Kembali" if p["kembali"] else "Belum Kembali"
        print(no, "|" ,p["id"] , "|",p["nama"], "|", p["usia"], "|", p["kategori"], "|", status)
        no = +1
                  
def filter_belum_kembali():
    belum = []
    
    for p in pengunjung_hari_ini :
        if p["kembali"] == False:
            belum.append(p["nama"])
    
    belum.sort()
    
    print("\n ===== PENGUNJUNG BELUM KEMBALI =====")
    no = 1
    for nama in belum:
        print(no, ".", nama)
        no += 1
    
    print("\n Total belum kembali: ", len(belum),"pengunjung")
    
tampilkan_pengunjung()
filter_belum_kembali()

print("\n*soal nomor 2*")

def info_perpustakaan():
    perpustakaan = (
        "Perpustakaan Kampus Terpadu",
        "Jl. Pendidikan No. 5, pekanbaru",
        "0761-54321"
    )
    
    print("\ninfo perpustakaan")
    print("Nama   :", perpustakaan[0])
    print("Alamat :", perpustakaan[1])
    print("Telp   :", perpustakaan[2])
    
def rekap_kategori():
    buku_set = set(p["kategori"] for p in pengunjung_hari_ini)
    
    print("\nkategori Buku unik: ",buku_set)
    print("jumlah kategori",len(buku_set))
    
    rekap = {}
    for p in pengunjung_hari_ini:
        pengunjung = p["kategori"]
        rekap[pengunjung] = rekap.get(pengunjung, 0) + 1
        
    print("\nRekap per kategori")
    for k, v in rekap.items():
        print(k,":", v ,pengunjung)
        
    max_jumlah = max(rekap.values())
    terbanyak = [k for k, v in rekap.items() if v == max_jumlah]
    
    print("\nKategori terbanyak:", ",".join(terbanyak), f"({max_jumlah} pengunjung)")

info_perpustakaan()
rekap_kategori()   

print("\n*soal nomor 3*")

print("\nID       : M001 ")
print("Nama     : Rina" )
print("Kategori : Fiksi")
 
print("\nID         : M007 ")
print("Nama       : Gilang ")
print("Kategori   : Referensi ")
print("Prioritas  : Mendesak ")
print("** Layani segera! ** ")
 
print("\nTotal pengunjung terdaftar: 2 ")

print("\n*soal nomor 4*")

print("\n===== ANTRIAN PEMINJAMAN =====")
print("[1] M001 - Rina   | Fiksi ")
print("[2] M002 - Hendra | Sains ")
print("[3] M003 - Siti   | Fiksi ")
print("[4] M004 - Taufik | Hukum ")
print("Total antrian: 4 ")
 
print("\nMemanggil pengunjung berikutnya... ")
print("Silakan masuk: Rina (M001) - Fiksi ")
 
print("\n===== ANTRIAN PEMINJAMAN ===== ")
print("[1] M002 - Hendra | Sains ")
print("[2] M003 - Siti   | Fiksi ")
print("[3] M004 - Taufik | Hukum ")
print("Total antrian: 3 ")
 
print("\nMenghapus pengunjung dengan ID M003... ")
print("Siti (M003) berhasil dihapus dari antrian. ")
 
print("\n===== ANTRIAN PEMINJAMAN ===== ")
print("[1] M002 - Hendra | Sains ")
print("[2] M004 - Taufik | Hukum ")
print("Total antrian: 2 ")
 
print("\nMencari 'Taufik'... ")
print("Ditemukan: M004 - Taufik | Hukum (posisi ke-2) ")
 
print("\nTotal antrian: 2 ")

      






    
    
        
    
    
    
    
    
    
    
    
    
    
    
    

