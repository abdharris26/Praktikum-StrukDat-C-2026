stok_gadget = [ 
{'merk': 'Samsung', 'tipe': 'S23', 'harga': 12000000}, 
{'merk': 'Oppo', 'tipe': 'Reno 10', 'harga': 6000000}, 
{'merk': 'Xiaomi', 'tipe': 'Mi 13', 'harga': 10000000}, 
{'merk': 'Iphone', 'tipe': '15 Pro', 'harga': 20000000}, 
] 

def filter_harga(stok_gadget):
    for x in stok_gadget:
        if x[1] <= max_harga:
            x[stok_gadget] == {max_harga}
        elif x[1] <= {min_gadget}:
        print(x[0])
    else:
        print("tidak ada gadget dalam rentang harga tersebut")
        

min_harga = input("masukan harga minimal: ")
max_harga = input("masukan maksimal harga: ")





