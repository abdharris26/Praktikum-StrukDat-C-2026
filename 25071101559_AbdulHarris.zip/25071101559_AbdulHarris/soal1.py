

gadget1 = {}
for x in gadget1:
    pass
    
def registrasi_gadget(merk, tipe, harga, sn):
    if harga > 1000000:
        print("harga tidak valid")
    else sn >5:
        print("serial number tidak valid")
        
inventaris []        
for i in range(3):  
    merk = input("masukan merk: ")
    tipe = input("masukan tipe barang: ")
    harga = input("masukan harga barang: ")
    sn = input("masukan serial number: ")
    if gadget:
        inventaris.append(gadget)
    else:
        print("registrasi gagal")

for item in inventaris:
    print(item)



        



       
    
    
    

    
    
     